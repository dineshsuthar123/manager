import React from 'react'
import { Layout, Card, Space, Tag, Typography } from 'antd'
import { AppstoreOutlined, EyeOutlined, InfoCircleOutlined, ArrowUpOutlined, ArrowDownOutlined } from '@ant-design/icons'
import TopNav from './components/TopNav'
import HiIshaCard from './components/HiIshaCard'
import TaskOverviewRow from './components/TaskOverviewRow'
import ProjectPanel from './components/ProjectPanel'
import QuickAction from './components/QuickAction'
import './nest-fixed.css'
import aiPic from '../../images/aipic.png'
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'

const { Header, Content } = Layout

export default function NestFixed() {
  // Inline data + helpers for the Code Activity mini chart
  const activityDays = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
  const hours = [8.5, 9, 9.2, 8.8, 8.4, 5.2, 3.4]
  const expected = [8.2, 8.4, 8.5, 8.5, 8.4, 6.1, 3.0]
  const activityData = activityDays.map((day, i) => ({ day, hours: hours[i], expected: expected[i] }))
  const commitData = [
    { day: 'Mon', commits: 9 },
    { day: 'Tue', commits: 7 },
    { day: 'Wed', commits: 10 },
    { day: 'Thu', commits: 8 },
    { day: 'Fri', commits: 6 },
    { day: 'Sat', commits: 4 },
    { day: 'Sun', commits: 3 },
  ]
  const reviewDonut = [
    { name: 'OnTime', value: 72, color: '#10B981' },
    { name: 'Warn', value: 14, color: '#FF9500' },
    { name: 'Late', value: 14, color: '#EF4444' },
  ]
  return (
    <Layout style={{ minHeight: '100vh', background: '#F5F6FA' }}>
      <Header style={{ background: '#fff', padding: '0 24px', position: 'sticky', top: 0, zIndex: 10, height: 64, display: 'flex', alignItems: 'center' }}>
        <TopNav />
      </Header>
      <Content style={{ padding: 16 }}>
        <div className="nest-stage">
          {/* Right rail (third column) */}
          <div className="right-col" aria-label="right-rail">
            <QuickAction />
            
            {/* Set Goals card */}
            <div className="card goals" aria-label="set-goals" style={{ marginTop: '24px' }}>
              {/* background image */}
              <img
                className="goals-img"
                src="https://images.unsplash.com/photo-1552581234-26160f608093?q=80&w=1200&auto=format&fit=crop"
                alt="Working at desk"
                loading="lazy"
              />
              {/* gradient shade per spec */}
              <div className="shade" aria-hidden />
              {/* frosted bottom overlay */}
              <div className="overlay">
                <div className="title">Time to set your annual goals</div>
                <div className="desc">Make plans to meet with your manager and set priorities for the upcoming year.</div>
                <button className="primary">Set goals</button>
              </div>
            </div>
          </div>
          {/* Left rail absolute cards */}
          <div className="left-card l-pdm" aria-label="product-development-metrics">
            <Card className="pdm-card" styles={{ body: { padding: 0 } }} style={{ height: '100%' }}>
              <div className="pdm-inner">
                <div className="pdm-head">
                  <div className="pdm-title">
                    <AppstoreOutlined className="pdm-cube" />
                    <span>PRODUCT DEVELOPMENT METRICS</span>
                  </div>
                  <div className="pdm-actions">
                    <InfoCircleOutlined />
                    <EyeOutlined />
                    <span className="good-pill">Good</span>
                  </div>
                </div>
                <div className="pdm-sub">Hover over each&nbsp; colored circle to view scores.</div>
                <div className="pdm-rows">
                  <div className="pdm-row">
                    <span className="lbl">Completed Task</span>
                    <div className="dots">
                      <span className="dot srib" />
                      <span className="dot team" />
                      <span className="dot group" />
                      <span className="dot part" />
                    </div>
                    <span className="val">80/400</span>
                  </div>
                  <div className="pdm-row">
                    <span className="lbl">Code Commit</span>
                    <div className="dots">
                      <span className="dot srib" />
                      <span className="dot team" />
                      <span className="dot group" />
                      <span className="dot part" />
                    </div>
                    <span className="val">78/400</span>
                  </div>
                  <div className="pdm-row">
                    <span className="lbl">Code Review</span>
                    <div className="dots">
                      <span className="dot srib" />
                      <span className="dot team" />
                      <span className="dot group" />
                      <span className="dot part" />
                    </div>
                    <span className="val">82/400</span>
                  </div>
                </div>
                <div className="pdm-legend">
                  <span className="legend"><span className="dot srib" /> SRIB</span>
                  <span className="legend"><span className="dot team" /> Team</span>
                  <span className="legend"><span className="dot group" /> Group</span>
                  <span className="legend"><span className="dot part" /> Part</span>
                </div>
              </div>
            </Card>
          </div>

          <div className="left-card l-quality" aria-label="code-quality">
            <Card className="quality-card" styles={{ body: { padding: 0 } }} style={{ height: '100%' }}>
              <div className="quality-inner">
                <div className="quality-head">
                  <div className="quality-title">
                    {/* code quality svg */}
                    <svg width="15" height="12" viewBox="0 0 15 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
                      <mask id="mask0_1_22529" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="15" height="12">
                        <path d="M0 0H15V12H0V0Z" fill="white"/>
                      </mask>
                      <g mask="url(#mask0_1_22529)">
                        <mask id="mask1_1_22529" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="15" height="12">
                          <path d="M0 0H15V12H0V0Z" fill="white"/>
                        </mask>
                        <g mask="url(#mask1_1_22529)">
                          <path d="M6.53682 10.7908L5.10713 10.4589C4.95713 10.4251 4.87276 10.2995 4.91494 10.1795L8.11414 1.36323C8.15636 1.24323 8.31341 1.17573 8.46341 1.20948L9.89306 1.54136C10.0431 1.57511 10.1274 1.70073 10.0853 1.82073L6.88603 10.637C6.84151 10.757 6.68682 10.8264 6.53682 10.7908ZM3.86494 8.68698L4.88447 7.81698C4.99228 7.72511 4.98526 7.57886 4.86572 7.49448L2.74228 6.00011L4.86572 4.50573C4.98526 4.42136 4.99463 4.27511 4.88447 4.18323L3.86494 3.31323C3.75947 3.22323 3.58135 3.21761 3.46651 3.30386L0.08916 5.83511C-0.0303711 5.92323 -0.0303711 6.07511 0.08916 6.16323L3.46651 8.69636C3.58135 8.78263 3.75947 8.77888 3.86494 8.68698ZM11.5337 8.69823L14.911 6.16511C15.0306 6.07698 15.0306 5.92511 14.911 5.83698L11.5337 3.30198C11.4212 3.21761 11.2431 3.22136 11.1353 3.31136L10.1157 4.18136C10.0079 4.27323 10.0149 4.41948 10.1345 4.50386L12.2579 6.00011L10.1345 7.49448C10.0149 7.57886 10.0056 7.72511 10.1157 7.81698L11.1353 8.68698C11.2407 8.77888 11.4189 8.78263 11.5337 8.69823Z" fill="#606060"/>
                        </g>
                      </g>
                    </svg>
                    <span>CODE QUALITY</span>
                  </div>
                  <div className="quality-actions">
                    <EyeOutlined />
                    <span className="good-pill">Good</span>
                  </div>
                </div>

                <div className="quality-rows">
                  {/* Code Coverage */}
                  <div className="quality-row with-progress">
                    <div className="label">
                      {/* same code icon */}
                      <svg width="15" height="12" viewBox="0 0 15 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
                        <mask id="mask0_a" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="15" height="12">
                          <path d="M0 0H15V12H0V0Z" fill="white"/>
                        </mask>
                        <g mask="url(#mask0_a)">
                          <mask id="mask1_a" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="15" height="12">
                            <path d="M0 0H15V12H0V0Z" fill="white"/>
                          </mask>
                          <g mask="url(#mask1_a)">
                            <path d="M6.53682 10.7908L5.10713 10.4589C4.95713 10.4251 4.87276 10.2995 4.91494 10.1795L8.11414 1.36323C8.15636 1.24323 8.31341 1.17573 8.46341 1.20948L9.89306 1.54136C10.0431 1.57511 10.1274 1.70073 10.0853 1.82073L6.88603 10.637C6.84151 10.757 6.68682 10.8264 6.53682 10.7908ZM3.86494 8.68698L4.88447 7.81698C4.99228 7.72511 4.98526 7.57886 4.86572 7.49448L2.74228 6.00011L4.86572 4.50573C4.98526 4.42136 4.99463 4.27511 4.88447 4.18323L3.86494 3.31323C3.75947 3.22323 3.58135 3.21761 3.46651 3.30386L0.08916 5.83511C-0.0303711 5.92323 -0.0303711 6.07511 0.08916 6.16323L3.46651 8.69636C3.58135 8.78263 3.75947 8.77888 3.86494 8.68698ZM11.5337 8.69823L14.911 6.16511C15.0306 6.07698 15.0306 5.92511 14.911 5.83698L11.5337 3.30198C11.4212 3.21761 11.2431 3.22136 11.1353 3.31136L10.1157 4.18136C10.0079 4.27323 10.0149 4.41948 10.1345 4.50386L12.2579 6.00011L10.1345 7.49448C10.0149 7.57886 10.0056 7.72511 10.1157 7.81698L11.1353 8.68698C11.2407 8.77888 11.4189 8.78263 11.5337 8.69823Z" fill="#606060"/>
                          </g>
                        </g>
                      </svg>
                      <span>Code Coverage</span>
                    </div>
                    <div className="value up"><ArrowUpOutlined /> 86%</div>
                    <div className="quality-progress"><div className="fill" style={{ width: '86%' }} /></div>
                  </div>

                  {/* Bug Rate */}
                  <div className="quality-row with-progress">
                    <div className="label">
                      {/* bug icon */}
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
                        <mask id="qbug0" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="12" height="12">
                          <path d="M0 0H12V12H0V0Z" fill="white"/>
                        </mask>
                        <g mask="url(#qbug0)">
                          <mask id="qbug1" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="12" height="12">
                            <path d="M0 0H12V12H0V0Z" fill="white"/>
                          </mask>
                          <g mask="url(#qbug1)">
                            <path d="M11.9997 6.77112C11.9885 7.1796 11.6431 7.5 11.2344 7.5H9.9375V7.875C9.9375 8.38746 9.82308 8.87304 9.61872 9.3081L11.0303 10.7197C11.3232 11.0126 11.3232 11.4874 11.0303 11.7803C10.7374 12.0733 10.2625 12.0732 9.96966 11.7803L8.68674 10.4975C8.10666 10.9679 7.36758 11.25 6.5625 11.25V5.53125C6.5625 5.37593 6.43656 5.25 6.28122 5.25H5.71874C5.56342 5.25 5.43749 5.37593 5.43749 5.53125V11.25C4.63238 11.25 3.89328 10.9679 3.31321 10.4975L2.03033 11.7803C1.73741 12.0733 1.26254 12.0732 0.969642 11.7803C0.67677 11.4874 0.67677 11.0126 0.969642 10.7197L2.38124 9.3081C2.17691 8.87304 2.06249 8.38746 2.06249 7.875V7.5H0.765594C0.356939 7.5 0.0114937 7.1796 0.000290529 6.77112C-0.0113579 6.34728 0.328767 6 0.749988 6H2.06249V4.62316L0.969642 3.53032C0.67677 3.23742 0.67677 2.76256 0.969642 2.46965C1.26256 2.17676 1.73741 2.17676 2.03033 2.46965L3.31065 3.75H8.68932L9.9696 2.46968C10.2625 2.17678 10.7374 2.17678 11.0303 2.46968C11.3232 2.76258 11.3232 3.23744 11.0303 3.53035L9.9375 4.62316V6H11.25C11.6712 6 12.0113 6.34728 11.9997 6.77112ZM6.0234 0C4.57367 0 3.39842 1.17525 3.39842 2.625H8.6484C8.6484 1.17525 7.47318 0 6.0234 0Z" fill="#606060"/>
                          </g>
                        </g>
                      </svg>
                      <span>Bug Rate</span>
                    </div>
                    <div className="value down"><ArrowDownOutlined /> 0.8%</div>
                    <div className="quality-progress"><div className="fill" style={{ width: '9.8%' }} /></div>
                  </div>

                  {/* Technical Debt */}
                  <div className="quality-row">
                    <div className="label">
                      {/* clock icon */}
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
                        <mask id="qclock0" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="12" height="12">
                          <path d="M0 0H12V12H0V0Z" fill="white"/>
                        </mask>
                        <g mask="url(#qclock0)">
                          <mask id="qclock1" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="12" height="12">
                            <path d="M0 0H12V12H0V0Z" fill="white"/>
                          </mask>
                          <g mask="url(#qclock1)">
                            <path d="M6 0.187256C2.78906 0.187256 0.1875 2.78882 0.1875 5.99976C0.1875 9.21072 2.78906 11.8123 6 11.8123C9.21096 11.8123 11.8125 9.21072 11.8125 5.99976C11.8125 2.78882 9.21096 0.187256 6 0.187256ZM8.16774 7.52322L7.69896 8.10912C7.63428 8.19 7.55052 8.23614 7.44756 8.2476C7.34466 8.25906 7.25274 8.23242 7.17186 8.16774L5.60156 7.00242C5.49044 6.91344 5.40406 6.80478 5.34242 6.6765C5.28079 6.54816 5.24998 6.4128 5.25 6.27048V2.62476C5.25 2.5212 5.28661 2.43282 5.35984 2.35959C5.43306 2.28637 5.52145 2.24976 5.625 2.24976H6.375C6.47856 2.24976 6.56694 2.28637 6.64014 2.35959C6.7134 2.43282 6.75 2.5212 6.75 2.62476V5.99976L8.10936 6.99588C8.1903 7.06056 8.23644 7.14444 8.24784 7.24746C8.25924 7.35042 8.23254 7.44234 8.16774 7.52322Z" fill="#606060"/>
                          </g>
                        </g>
                      </svg>
                      <span>Technical Debt</span>
                    </div>
                    <div className="value neutral">Low</div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          <div className="left-card l-activity" aria-label="code-activity">
            <Card className="activity-card" styles={{ body: { padding: 0 } }} style={{ height: '100%' }}>
              <div className="activity-inner">
                <div className="activity-head">
                  <div className="activity-title">
                    {/* code icon */}
                    <svg width="15" height="12" viewBox="0 0 15 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
                      <mask id="mask0_ca" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="15" height="12">
                        <path d="M0 0H15V12H0V0Z" fill="white"/>
                      </mask>
                      <g mask="url(#mask0_ca)">
                        <mask id="mask1_ca" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="0" y="0" width="15" height="12">
                          <path d="M0 0H15V12H0V0Z" fill="white"/>
                        </mask>
                        <g mask="url(#mask1_ca)">
                          <path d="M6.53682 10.7908L5.10713 10.4589C4.95713 10.4251 4.87276 10.2995 4.91494 10.1795L8.11414 1.36323C8.15636 1.24323 8.31341 1.17573 8.46341 1.20948L9.89306 1.54136C10.0431 1.57511 10.1274 1.70073 10.0853 1.82073L6.88603 10.637C6.84151 10.757 6.68682 10.8264 6.53682 10.7908ZM3.86494 8.68698L4.88447 7.81698C4.99228 7.72511 4.98526 7.57886 4.86572 7.49448L2.74228 6.00011L4.86572 4.50573C4.98526 4.42136 4.99463 4.27511 4.88447 4.18323L3.86494 3.31323C3.75947 3.22323 3.58135 3.21761 3.46651 3.30386L0.08916 5.83511C-0.0303711 5.92323 -0.0303711 6.07511 0.08916 6.16323L3.46651 8.69636C3.58135 8.78263 3.75947 8.77888 3.86494 8.68698ZM11.5337 8.69823L14.911 6.16511C15.0306 6.07698 15.0306 5.92511 14.911 5.83698L11.5337 3.30198C11.4212 3.21761 11.2431 3.22136 11.1353 3.31136L10.1157 4.18136C10.0079 4.27323 10.0149 4.41948 10.1345 4.50386L12.2579 6.00011L10.1345 7.49448C10.0149 7.57886 10.0056 7.72511 10.1157 7.81698L11.1353 8.68698C11.2407 8.77888 11.4189 8.78263 11.5337 8.69823Z" fill="#606060"/>
                        </g>
                      </g>
                    </svg>
                    <span>CODE ACTIVITY</span>
                  </div>
                  <div className="activity-actions">
                    <EyeOutlined />
                    <span className="pill-improved">improved</span>
                  </div>
                </div>

                <div className="activity-chart">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={activityData} margin={{ top: 8, right: 8, left: 0, bottom: 16 }}>
                            <CartesianGrid stroke="#E5E7EB" strokeDasharray="2 6" />
                            <XAxis dataKey="day" tick={{ fontSize: 10, fill: '#6B7280' }} axisLine={{ stroke: '#E5E7EB' }} tickLine={false} />
                            <YAxis domain={[0, 12]} ticks={[0,2,4,6,8,10,12]} tick={{ fontSize: 10, fill: '#999' }} axisLine={{ stroke: '#E5E7EB' }} tickLine={false} />
                            <Tooltip cursor={{ stroke: '#DDD' }} />
                            <Line type="monotone" dataKey="expected" stroke="#4CAF50" strokeWidth={2} strokeDasharray="5 4" dot={{ r: 2, strokeWidth: 1, fill: '#fff' }} />
                            <Line type="monotone" dataKey="hours" stroke="#38AEE0" strokeWidth={2} dot={{ r: 2, strokeWidth: 1, fill: '#fff' }} />
                          </LineChart>
                        </ResponsiveContainer>
                </div>

                <div className="activity-legend">
                  <span className="legend"><span className="dot team"/> Hours</span>
                  <span className="legend"><span className="dot group"/> Expected</span>
                </div>
                <div className="activity-total">Total <strong>43 Hrs</strong> Coding Time</div>
              </div>
            </Card>
          </div>

          <div className="left-card l-commit" aria-label="commit-analysis">
            <Card className="commit-card" title={<span style={{ fontWeight: 700 }}>Commit Analysis</span>} extra={<Tag color="blue">stable</Tag>} styles={{ body: { padding: 12 } }} style={{ height: '100%' }}>
              <div className="commit-chart">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={commitData} margin={{ top: 4, right: 8, left: 0, bottom: 8 }}>
                    <CartesianGrid stroke="#E5E7EB" vertical={false} />
                    <XAxis dataKey="day" tick={{ fontSize: 10, fill: '#6B7280' }} axisLine={{ stroke: '#E5E7EB' }} tickLine={false} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: '#999' }} axisLine={{ stroke: '#E5E7EB' }} tickLine={false} />
                    <Tooltip cursor={{ fill: 'rgba(0,0,0,.03)' }} />
                    <Bar dataKey="commits" fill="#38AEE0" radius={[4,4,0,0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <Typography.Text style={{ display: 'block', marginTop: 8 }}><strong>8.2</strong> Daily Average Commits</Typography.Text>
            </Card>
          </div>

          <div className="left-card l-review" aria-label="code-review-status">
            <Card className="review-card" styles={{ body: { padding: 0 } }} style={{ height: '100%' }}>
              <div className="review-inner">
                <div className="review-head">
                  <div className="review-title">
                    {/* simple eye-like lines icon left of text */}
                    <svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
                      <path d="M1 6C1 6 3.8 2 8 2C12.2 2 15 6 15 6C15 6 12.2 10 8 10C3.8 10 1 6 1 6Z" stroke="#606060"/>
                      <circle cx="8" cy="6" r="2" stroke="#606060"/>
                    </svg>
                    <span>CODE REVIEW STATUS</span>
                  </div>
                  <div className="review-actions">
                    <EyeOutlined />
                    <span className="pill-warn">needs improvement</span>
                  </div>
                </div>
                <div className="review-body">
                  <div className="review-chart">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie data={reviewDonut} dataKey="value" nameKey="name" innerRadius={24} outerRadius={35} startAngle={90} endAngle={-270} paddingAngle={2} cornerRadius={4}>
                          {reviewDonut.map((s, i) => (
                            <Cell key={i} fill={s.color} />
                          ))}
                        </Pie>
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="review-copy">
                    <Typography.Title level={5} style={{ margin: 0 }}>4.2 Hrs</Typography.Title>
                    <Typography.Text type="secondary">Average Review Time</Typography.Text>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Centered fixed column (708px) with absolute children at requested positions */}
          <div className="nest-fixed-center" aria-label="center-stack">
          <div className="center-hiisha" aria-label="hiisha">
            <HiIshaCard />
          </div>

          <div className="center-task-overview" aria-label="task-overview">
            <div className="overview-lead">Here's your <strong>TASK OVERVIEW</strong></div>
            <TaskOverviewRow />
          </div>

          <div className="center-ai-card" aria-label="ai-powered">
            <Card title={<Space><span>AI Powered Solutions</span></Space>} styles={{ body: { padding: 16 } }}>
              <div className="ai-card-grid">
                <img
                  className="ai-card-image"
                  src={aiPic}
                  alt="AI Powered"
                  loading="lazy"
                />
                <div className="ai-card-list">
                  <Card size="small" styles={{ body: { padding: 12 } }}>
                    <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                      <Typography.Text strong>Analysis for: Memory leak in dashboard</Typography.Text>
                      <Tag color="red">Critical</Tag>
                    </Space>
                    <Typography.Paragraph type="secondary" style={{ margin: '6px 0 0' }}>
                      Potential memory leak detected in useEffect cleanup. Suggested solution: proper cleanup.
                    </Typography.Paragraph>
                  </Card>
                  <Card size="small" styles={{ body: { padding: 12 } }}>
                    <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                      <Typography.Text strong>Analysis for: API response timeout</Typography.Text>
                      <Tag color="orange">High</Tag>
                    </Space>
                    <Typography.Paragraph type="secondary" style={{ margin: '6px 0 0' }}>
                      Implement retry with exponential backoff to reduce failures.
                    </Typography.Paragraph>
                  </Card>
                  <Card size="small" styles={{ body: { padding: 12 } }}>
                    <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                      <Typography.Text strong>Analysis for: UI rendering issue</Typography.Text>
                      <Tag color="orange">High</Tag>
                    </Space>
                    <Typography.Paragraph type="secondary" style={{ margin: '6px 0 0' }}>
                      Avoid unnecessary re-renders by using React.memo and useCallback.
                    </Typography.Paragraph>
                  </Card>
                </div>
              </div>
            </Card>
          </div>

            <div className="center-project-panel" aria-label="project-panel">
              <ProjectPanel />
            </div>
          </div>
        </div>
      </Content>
    </Layout>
  )
}