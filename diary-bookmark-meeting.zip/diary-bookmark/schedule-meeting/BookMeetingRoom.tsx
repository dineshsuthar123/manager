import React, { useState } from 'react'
import TopNav from './components/TopNav'
import SearchFilters from './components/SearchFilters'
import ReservationLegend from './components/ReservationLegend'
import TimeGrid from './components/TimeGrid'
import MeetingDetailsModal from './components/MeetingDetailsModal'
import MyReservationModal from './components/MyReservationModal'

export default function BookMeetingRoom() {
    const [isMeetingModalVisible, setIsMeetingModalVisible] = useState(false)
    const [isReservationModalVisible, setIsReservationModalVisible] = useState(false)

    const handleOpenMeetingModal = () => {
        setIsMeetingModalVisible(true)
    }

    const handleCloseMeetingModal = () => {
        setIsMeetingModalVisible(false)
    }

    const handleOpenReservationModal = () => setIsReservationModalVisible(true)
    const handleCloseReservationModal = () => setIsReservationModalVisible(false)

    return (
        <div className="book-meeting-room">
            <TopNav />
            <div className="main-content">
                <SearchFilters onOpenReservationStatus={handleOpenReservationModal} />
                <div className="my-reservation-status">
                    <button
                        type="button"
                        className="reservation-status-btn"
                        onClick={handleOpenReservationModal}
                    >
                        My Reservation Status
                    </button>
                </div>
                <ReservationLegend />
                <TimeGrid onOpenMeetingModal={handleOpenMeetingModal} />
            </div>
            <MeetingDetailsModal 
                visible={isMeetingModalVisible}
                onClose={handleCloseMeetingModal}
            />
            <MyReservationModal 
                visible={isReservationModalVisible}
                onClose={handleCloseReservationModal}
            />
        </div>
    )
}