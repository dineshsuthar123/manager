import React, { useState } from 'react'
import { Select, Button, Input, Switch, DatePicker } from 'antd'
import dayjs from 'dayjs'
import { SearchOutlined, EnvironmentOutlined, CalendarOutlined, ClockCircleOutlined, TeamOutlined, ToolOutlined } from '@ant-design/icons'

const { Option } = Select

interface SearchFiltersProps {
    onOpenReservationStatus?: () => void
}

export default function SearchFilters({ onOpenReservationStatus }: SearchFiltersProps) {
    const [recurrence, setRecurrence] = useState(true)
    const [dateRange, setDateRange] = useState<[dayjs.Dayjs, dayjs.Dayjs]>([dayjs('2025-07-04'), dayjs('2025-07-23')])
    const [selectedDays, setSelectedDays] = useState<Set<string>>(new Set(['M','T','W','T2','F','S']))
    const days: { key: string; label: string }[] = [
        { key: 'M', label: 'M' },
        { key: 'T', label: 'T' },
        { key: 'W', label: 'W' },
        { key: 'T2', label: 'T' },
        { key: 'F', label: 'F' },
        { key: 'S', label: 'S' },
        { key: 'S2', label: 'S' },
    ]
    const toggleDay = (k: string) => {
        setSelectedDays(prev => {
            const next = new Set(prev)
            if (next.has(k)) {
                next.delete(k)
            } else {
                next.add(k)
            }
            return next
        })
    }
    return (
        <div className="search-filters">
            <div className="breadcrumb">
                <span className="breadcrumb-text">My Workspace {'>'} Book a Meeting Room</span>
            </div>
            
            <div className="page-title">
                <h1>Book a Meeting Room</h1>
            </div>

            {/* My Reservation Status button moved to absolute positioned container in parent (BookMeetingRoom) */}

            <div className="filter-row">
                <div className="filter-item">
                    <label>Building & Floor</label>
                    <div className="filter-control">
                        <EnvironmentOutlined />
                        <Select defaultValue="Phoenix" style={{ width: 120 }}>
                            <Option value="Phoenix">Phoenix</Option>
                            <Option value="Alpha">Alpha</Option>
                        </Select>
                        <Select defaultValue="Floor 3" style={{ width: 80 }}>
                            <Option value="Floor 1">Floor 1</Option>
                            <Option value="Floor 2">Floor 2</Option>
                            <Option value="Floor 3">Floor 3</Option>
                        </Select>
                    </div>
                </div>

                <div className="filter-item" style={{ minWidth: 280 }}>
                    <label style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                        <span>Date</span>
                        <span style={{ fontWeight: 500, fontSize: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
                            Re-occurrence <Switch size="small" checked={recurrence} onChange={setRecurrence} />
                        </span>
                    </label>
                    <div className="filter-control" style={{ flexDirection: 'column', alignItems: 'flex-start', gap: 6 }}>
                        <DatePicker.RangePicker
                            value={dateRange}
                            onChange={(vals) => {
                                if (vals && vals[0] && vals[1]) setDateRange([vals[0], vals[1]])
                            }}
                            format={(val) => val.format('D MMM YYYY')}
                            allowClear={false}
                            style={{ width: 260 }}
                        />
                        <div style={{
                            height: 36,
                            display: 'flex',
                            alignItems: 'center',
                            gap: 10,
                            paddingTop: 4,
                            visibility: recurrence ? 'visible' : 'hidden'
                        }}>
                            <span style={{ fontWeight: 600, fontSize: 12 }}>Days</span>
                            {days.map(d => (
                                <button
                                    key={d.key}
                                    type="button"
                                    onClick={() => toggleDay(d.key)}
                                    style={{
                                        width: 26,
                                        height: 26,
                                        borderRadius: '50%',
                                        border: '2px solid #42AFFF',
                                        background: selectedDays.has(d.key) ? '#42AFFF' : 'transparent',
                                        color: selectedDays.has(d.key) ? '#fff' : '#0E1525',
                                        fontSize: 12,
                                        fontWeight: 600,
                                        lineHeight: '1',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        cursor: 'pointer',
                                        padding: 0,
                                        transition: 'background .15s, color .15s'
                                    }}
                                >
                                    {d.label}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="filter-item">
                    <label>Time</label>
                    <div className="filter-control">
                        <ClockCircleOutlined />
                        <Select defaultValue="11:00" style={{ width: 80 }}>
                            <Option value="09:00">09:00</Option>
                            <Option value="10:00">10:00</Option>
                            <Option value="11:00">11:00</Option>
                            <Option value="12:00">12:00</Option>
                        </Select>
                        <span>to</span>
                        <Select defaultValue="11:30" style={{ width: 80 }}>
                            <Option value="09:30">09:30</Option>
                            <Option value="10:30">10:30</Option>
                            <Option value="11:30">11:30</Option>
                            <Option value="12:30">12:30</Option>
                        </Select>
                    </div>
                </div>

                <div className="filter-item">
                    <label>Seats</label>
                    <div className="filter-control">
                        <TeamOutlined />
                        <Select defaultValue="5-6 people" style={{ width: 120 }}>
                            <Option value="1-2 people">1-2 people</Option>
                            <Option value="3-4 people">3-4 people</Option>
                            <Option value="5-6 people">5-6 people</Option>
                            <Option value="7+ people">7+ people</Option>
                        </Select>
                    </div>
                </div>

                <div className="filter-item">
                    <label>Conference room</label>
                    <div className="filter-control">
                        <Input placeholder="Type here" />
                    </div>
                </div>

                <div className="filter-item">
                    <label>Supplies</label>
                    <div className="filter-control">
                        <ToolOutlined />
                        <Input placeholder="Type here" />
                    </div>
                </div>

                <Button type="primary" className="search-btn">
                    <SearchOutlined />
                    Search
                </Button>
            </div>
        </div>
    )
}