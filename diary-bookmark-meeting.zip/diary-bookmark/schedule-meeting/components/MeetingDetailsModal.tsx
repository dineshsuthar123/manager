import React, { useState } from 'react'

interface MeetingDetailsModalProps {
    visible: boolean
    onClose: () => void
}

export default function MeetingDetailsModal({ visible, onClose }: MeetingDetailsModalProps) {
    const [title, setTitle] = useState('')
    const [description, setDescription] = useState('Add description here')
    const [meetingKind, setMeetingKind] = useState('Problem Implementation')
    const [building, setBuilding] = useState('Phoenix')
    const [floor, setFloor] = useState('Floor 3')
    const [date, setDate] = useState('8 May 2025')
    const [timeFrom, setTimeFrom] = useState('11.00')
    const [timeTo, setTimeTo] = useState('11.30')
    const [seats, setSeats] = useState('5-6 people')
    const [recurrence, setRecurrence] = useState(false)
    const [recurrenceDays, setRecurrenceDays] = useState<Set<string>>(new Set(['M','T','W','T2','F']))
    const dayDefs = [
        { key: 'M', label: 'M' },
        { key: 'T', label: 'T' },
        { key: 'W', label: 'W' },
        { key: 'T2', label: 'T' },
        { key: 'F', label: 'F' },
        { key: 'S', label: 'S' },
        { key: 'S2', label: 'S' }
    ]
    const toggleRecurrenceDay = (k: string) => {
        setRecurrenceDays(prev => {
            const next = new Set(prev)
            if (next.has(k)) {
                next.delete(k)
            } else {
                next.add(k)
            }
            return next
        })
    }
    const [organizer, setOrganizer] = useState('Isha Kumar')
    const [attendees, setAttendees] = useState(['John A', 'Smitha Reddy', 'Manoj M', 'Rakshita M'])

    if (!visible) return null

    const removeAttendee = (index: number) => {
        setAttendees(attendees.filter((_, i) => i !== index))
    }

    return (
        <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000
        }}>
            <div className="modal-overlay" onClick={onClose} style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0
            }}></div>
            
            <div style={{
                position: 'absolute',
                width: '947px',
                height: '878px',
                left: 'calc(50% - 947px/2 + 0.5px)',
                top: 'calc(50% - 878px/2)',
                background: '#FFFFFF',
                boxShadow: '0px 4px 7px rgba(31, 54, 199, 0.06)',
                borderRadius: '8px'
            }}>
                {/* Header */}
                <div style={{
                    position: 'absolute',
                    width: '947px',
                    height: '45px',
                    left: '0px',
                    top: '0px',
                    background: '#E6F4FF',
                    borderRadius: '8px 8px 0px 0px'
                }}>
                    <span style={{
                        position: 'absolute',
                        width: '392px',
                        height: '31px',
                        left: '31px',
                        top: '7px',
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        fontSize: '20px',
                        lineHeight: '44px',
                        letterSpacing: '0.01em',
                        color: '#202224'
                    }}>Meeting Details</span>
                </div>

                {/* Meeting Kind */}
                <div style={{
                    position: 'absolute',
                    width: '71px',
                    height: '14px',
                    left: '743px',
                    top: '58px',
                    fontFamily: 'Samsung InterFace',
                    fontStyle: 'normal',
                    fontWeight: 700,
                    fontSize: '12px',
                    lineHeight: '14px',
                    color: '#202224'
                }}>
                    Meeting Kind
                </div>

                <div style={{
                    position: 'absolute',
                    width: '182px',
                    height: '42px',
                    left: '733px',
                    top: '78px',
                    background: '#FFFFFF',
                    border: '0.5px solid #606060',
                    borderRadius: '10px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    paddingLeft: '16px',
                    paddingRight: '16px'
                }}>
                    <span style={{
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        fontSize: '12px',
                        lineHeight: '20px',
                        color: '#202224'
                    }}>
                        {meetingKind}
                    </span>
                    <svg width="10" height="5" viewBox="0 0 10 5" fill="none">
                        <path d="M0 0L5 5L10 0" stroke="#202224" strokeWidth="1"/>
                    </svg>
                </div>

                {/* Title */}
                <input
                    type="text"
                    placeholder="Enter Title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    style={{
                        position: 'absolute',
                        width: '392px',
                        height: '33px',
                        left: '32px',
                        top: '82px',
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 700,
                        fontSize: '24px',
                        lineHeight: '34px',
                        letterSpacing: '0.01em',
                        color: '#202224',
                        border: 'none',
                        outline: 'none',
                        background: 'transparent'
                    }}
                />

                {/* Description */}
                <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    style={{
                        position: 'absolute',
                        width: '851px',
                        height: '148px',
                        left: '30px',
                        top: '142px',
                        background: '#F3F8FF',
                        borderRadius: '8px',
                        padding: '16px',
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        fontSize: '20px',
                        lineHeight: '34px',
                        letterSpacing: '0.01em',
                        color: '#606060',
                        border: 'none',
                        resize: 'none',
                        outline: 'none'
                    }}
                />

                {/* Labels Row */}
                <div style={{
                    position: 'absolute',
                    left: '32px',
                    top: '338px',
                    fontFamily: 'Samsung InterFace',
                    fontStyle: 'normal',
                    fontWeight: 700,
                    fontSize: '14px',
                    lineHeight: '17px',
                    color: '#202224'
                }}>Building & Floor</div>

                <div style={{
                    position: 'absolute',
                    left: '248px',
                    top: '338px',
                    fontFamily: 'Samsung InterFace',
                    fontStyle: 'normal',
                    fontWeight: 700,
                    fontSize: '14px',
                    lineHeight: '17px',
                    color: '#202224'
                }}>Date</div>

                <div style={{
                    position: 'absolute',
                    left: '476px',
                    top: '338px',
                    fontFamily: 'Samsung InterFace',
                    fontStyle: 'normal',
                    fontWeight: 700,
                    fontSize: '14px',
                    lineHeight: '17px',
                    color: '#202224'
                }}>Time</div>

                <div style={{
                    position: 'absolute',
                    left: '684px',
                    top: '338px',
                    fontFamily: 'Samsung InterFace',
                    fontStyle: 'normal',
                    fontWeight: 700,
                    fontSize: '14px',
                    lineHeight: '17px',
                    color: '#202224'
                }}>Seats</div>

                {/* Input Fields Row */}
                <div style={{
                    position: 'absolute',
                    width: '192px',
                    height: '44px',
                    left: '29px',
                    top: '365px',
                    background: '#FFFFFF',
                    border: '0.5px solid #E5E7EB',
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    paddingLeft: '16px',
                    paddingRight: '16px'
                }}>
                    <span style={{
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        fontSize: '14px',
                        lineHeight: '20px',
                        color: '#202224'
                    }}>🏢 {building} &gt; {floor}</span>
                </div>

                <div style={{
                    position: 'absolute',
                    width: '223px',
                    height: '44px',
                    left: '237px',
                    top: '365px',
                    background: '#FFFFFF',
                    border: '0.5px solid #E5E7EB',
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    paddingLeft: '16px',
                    paddingRight: '16px'
                }}>
                    <span style={{
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        fontSize: '14px',
                        lineHeight: '20px',
                        color: '#202224'
                    }}>{date}</span>
                    <svg width="16" height="16" fill="#667185">
                        <path d="M3 5h18v16H3z M16 3v4M8 3v4M3 10h18" stroke="currentColor" strokeWidth="1"/>
                    </svg>
                </div>

                <div style={{
                    position: 'absolute',
                    width: '192px',
                    height: '44px',
                    left: '476px',
                    top: '365px',
                    background: '#FFFFFF',
                    border: '0.5px solid #E5E7EB',
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    paddingLeft: '16px',
                    paddingRight: '16px'
                }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <svg width="16" height="16" fill="#667185">
                            <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="1" fill="none"/>
                            <path d="M8 4v4l3 3" stroke="currentColor" strokeWidth="1"/>
                        </svg>
                        <span style={{
                            fontFamily: 'Samsung InterFace',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            fontSize: '14px',
                            lineHeight: '20px',
                            color: '#202224'
                        }}>{timeFrom}</span>
                        <span style={{ color: '#667185', fontWeight: 700 }}>to</span>
                        <span style={{
                            fontFamily: 'Samsung InterFace',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            fontSize: '14px',
                            lineHeight: '20px',
                            color: '#202224'
                        }}>{timeTo}</span>
                    </div>
                </div>

                <div style={{
                    position: 'absolute',
                    width: '229px',
                    height: '44px',
                    left: '684px',
                    top: '365px',
                    background: '#FFFFFF',
                    border: '0.5px solid #E5E7EB',
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    paddingLeft: '16px',
                    paddingRight: '16px'
                }}>
                {/* Recurrence toggle & days row */}
                <div style={{
                    position: 'absolute',
                    left: '237px',
                    top: '416px',
                    width: '440px',
                    height: recurrence ? '54px' : '24px'
                }}>
                    <label style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 700,
                        fontSize: '12px',
                        lineHeight: '14px',
                        color: '#202224',
                        cursor: 'pointer'
                    }}>
                        <input
                            type="checkbox"
                            checked={recurrence}
                            onChange={e => setRecurrence(e.target.checked)}
                            style={{ cursor: 'pointer' }}
                        />
                        Re-occurrence
                    </label>
                    <div style={{
                        marginTop: 8,
                        display: 'flex',
                        gap: '10px',
                        alignItems: 'center',
                        visibility: recurrence ? 'visible' : 'hidden'
                    }}>
                        <span style={{ fontWeight: 600, fontSize: 12 }}>Days</span>
                        {dayDefs.map(d => (
                            <button
                                key={d.key}
                                onClick={() => toggleRecurrenceDay(d.key)}
                                style={{
                                    width: 26,
                                    height: 26,
                                    borderRadius: '50%',
                                    border: '2px solid #42AFFF',
                                    background: recurrenceDays.has(d.key) ? '#42AFFF' : 'transparent',
                                    color: recurrenceDays.has(d.key) ? '#fff' : '#0E1525',
                                    fontSize: 12,
                                    fontWeight: 600,
                                    lineHeight: '1',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    cursor: 'pointer',
                                    padding: 0
                                }}
                            >{d.label}</button>
                        ))}
                    </div>
                </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <svg width="16" height="16" fill="#667185">
                            <path d="M16 5v6a1 1 0 01-1 1H9l-3 3v-3H5a1 1 0 01-1-1V5a1 1 0 011-1h10a1 1 0 011 1z" stroke="currentColor" strokeWidth="1"/>
                        </svg>
                        <span style={{
                            fontFamily: 'Samsung InterFace',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            fontSize: '15px',
                            lineHeight: '20px',
                            color: '#202224'
                        }}>{seats}</span>
                    </div>
                    <svg width="10" height="5" viewBox="0 0 10 5" fill="none">
                        <path d="M0 0L5 5L10 0" stroke="#667185" strokeWidth="1"/>
                    </svg>
                </div>

                {/* Attendees Section */}
                <div style={{
                    position: 'absolute',
                    left: '32px',
                    top: '434px',
                    fontFamily: 'Samsung InterFace',
                    fontStyle: 'normal',
                    fontWeight: 700,
                    fontSize: '14px',
                    lineHeight: '20px',
                    color: '#202224'
                }}>Attendees</div>

                <div style={{
                    position: 'absolute',
                    width: '20px',
                    height: '20px',
                    left: '100px',
                    top: '435px',
                    background: '#BB7EFC',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontFamily: 'Samsung InterFace',
                    fontStyle: 'normal',
                    fontWeight: 400,
                    fontSize: '14px',
                    lineHeight: '10px',
                    color: '#FFFFFF'
                }}>{attendees.length}</div>

                <div style={{
                    position: 'absolute',
                    left: '566px',
                    top: '435px',
                    fontFamily: 'Samsung InterFace',
                    fontStyle: 'normal',
                    fontWeight: 700,
                    fontSize: '14px',
                    lineHeight: '20px',
                    color: '#202224'
                }}>Organizer</div>

                <input
                    type="text"
                    value={organizer}
                    onChange={(e) => setOrganizer(e.target.value)}
                    style={{
                        position: 'absolute',
                        left: '637px',
                        top: '431px',
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        fontSize: '12px',
                        lineHeight: '20px',
                        color: '#000000',
                        border: 'none',
                        background: 'transparent',
                        outline: 'none'
                    }}
                />

                <svg style={{
                    position: 'absolute',
                    width: '16px',
                    height: '16px',
                    left: '883px',
                    top: '432px'
                }} fill="#606060">
                    <circle cx="8" cy="5" r="3" stroke="currentColor" strokeWidth="1" fill="none"/>
                    <path d="M15 15l-3-3" stroke="currentColor" strokeWidth="1"/>
                </svg>

                {/* Attendees Container */}
                <div style={{
                    position: 'absolute',
                    width: '883px',
                    height: '171px',
                    left: '30px',
                    top: '468px',
                    background: '#F3F8FF',
                    borderRadius: '8px',
                    padding: '18px'
                }}>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', marginTop: '18px' }}>
                        {attendees.map((attendee, index) => (
                            <div key={index} style={{
                                display: 'flex',
                                alignItems: 'center',
                                padding: '5px 12px',
                                gap: '12px',
                                background: '#FFFFFF',
                                borderRadius: '4px',
                                fontFamily: 'Samsung InterFace',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                fontSize: '12px',
                                lineHeight: '20px',
                                color: '#202224'
                            }}>
                                {attendee}
                                <div
                                    onClick={() => removeAttendee(index)}
                                    style={{
                                        width: '12px',
                                        height: '12px',
                                        background: '#666666',
                                        cursor: 'pointer',
                                        borderRadius: '2px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        color: 'white',
                                        fontSize: '10px'
                                    }}
                                >×</div>
                            </div>
                        ))}
                    </div>

                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        marginTop: '32px',
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        fontSize: '12px',
                        lineHeight: '20px',
                        color: '#202224',
                        cursor: 'pointer'
                    }}>
                        👤 Add Attendee
                    </div>
                </div>

                {/* Upload Files Section */}
                <div style={{
                    position: 'absolute',
                    left: '30px',
                    top: '659px',
                    width: '883px'
                }}>
                    <div style={{
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 700,
                        fontSize: '14px',
                        lineHeight: '20px',
                        color: '#202224',
                        marginBottom: '16px'
                    }}>
                        Upload files
                    </div>

                    {/* Upload Area */}
                    <div style={{
                        width: '883px',
                        height: '96px',
                        background: '#FFFFFF',
                        border: '2px dashed #D1D5DB',
                        borderRadius: '8px',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '8px',
                        marginBottom: '16px'
                    }}>
                        <div style={{
                            fontFamily: 'Samsung InterFace',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            fontSize: '14px',
                            lineHeight: '20px',
                            color: '#6B7280'
                        }}>
                            Drop File here or{' '}
                            <span style={{
                                color: '#38AEE0',
                                cursor: 'pointer',
                                textDecoration: 'underline'
                            }}>
                                Browse file
                            </span>
                        </div>
                    </div>

                    {/* File Attachment Info */}
                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        marginBottom: '16px'
                    }}>
                        <svg width="16" height="16" fill="#003477">
                            <path d="M8 2v8m-4-4h8" stroke="currentColor" strokeWidth="1"/>
                        </svg>
                        <span style={{
                            fontFamily: 'Samsung InterFace',
                            fontStyle: 'normal',
                            fontWeight: 700,
                            fontSize: '12px',
                            lineHeight: '10px',
                            color: '#202224'
                        }}>
                            Attach File upto 50.MB
                        </span>
                    </div>
                    
                    {/* Attached File */}
                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        padding: '4px 8px',
                        background: '#DEF5FF',
                        borderRadius: '4px',
                        width: '110px'
                    }}>
                        <svg width="16" height="16" fill="#003477">
                            <rect x="3" y="2" width="10" height="12" rx="1" stroke="currentColor" strokeWidth="1" fill="none"/>
                        </svg>
                        <span style={{
                            fontFamily: 'Samsung InterFace',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            fontSize: '12px',
                            lineHeight: '10px',
                            color: '#5E5E68'
                        }}>Design Draft</span>
                        <div style={{ marginLeft: 'auto', cursor: 'pointer', fontSize: '10px' }}>×</div>
                    </div>
                </div>

                {/* Footer */}
                <div style={{
                    position: 'absolute',
                    left: '22px',
                    top: '825px',
                    right: '22px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                }}>
                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '24px',
                        fontFamily: 'Samsung InterFace',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        fontSize: '14px',
                        lineHeight: '20px',
                        color: '#202224'
                    }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            Link to PMS
                            <div style={{
                                width: '39px',
                                height: '24px',
                                background: '#D9D9D9',
                                borderRadius: '100px',
                                position: 'relative'
                            }}>
                                <div style={{
                                    position: 'absolute',
                                    width: '20px',
                                    height: '20px',
                                    right: '17px',
                                    top: '2px',
                                    background: '#FFFFFF',
                                    boxShadow: '0px 0px 0px 1px rgba(0, 0, 0, 0.04), 0px 3px 8px rgba(0, 0, 0, 0.15), 0px 3px 1px rgba(0, 0, 0, 0.06)',
                                    borderRadius: '100px'
                                }}></div>
                            </div>
                        </label>

                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <input type="checkbox" defaultChecked />
                            Send Email to attendees
                        </label>

                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <input type="checkbox" defaultChecked />
                            Alert via Email to all Attendees 30 mins prior
                        </label>

                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <input type="radio" name="visibility" />
                            Public
                        </label>

                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <input type="radio" name="visibility" defaultChecked />
                            Private
                        </label>
                    </div>

                    <div style={{ display: 'flex', gap: '16px' }}>
                        <button
                            onClick={onClose}
                            style={{
                                width: '95px',
                                height: '48px',
                                border: '1px solid #606060',
                                borderRadius: '10px',
                                background: 'transparent',
                                fontFamily: 'Samsung InterFace',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                fontSize: '14px',
                                lineHeight: '22px',
                                color: '#606060',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '8px'
                            }}
                        >
                            <svg width="20" height="20" fill="currentColor">
                                <path d="M6 6l8 8M6 14l8-8" stroke="currentColor" strokeWidth="2"/>
                            </svg>
                            Cancel
                        </button>
                        
                        <button
                            style={{
                                width: '95px',
                                height: '48px',
                                background: '#38AEE0',
                                border: 'none',
                                borderRadius: '10px',
                                fontFamily: 'Samsung InterFace',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                fontSize: '14px',
                                lineHeight: '22px',
                                color: '#FFFFFF',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '8px'
                            }}
                        >
                            <svg width="20" height="20" fill="currentColor">
                                <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2" fill="none"/>
                            </svg>
                            Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}