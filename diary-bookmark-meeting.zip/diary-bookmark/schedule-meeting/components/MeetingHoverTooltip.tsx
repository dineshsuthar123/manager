import React from 'react'

export interface MeetingHoverTooltipProps {
  meeting: {
    title: string
    details?: {
      time: string
      attendees: number
      organizer: string
    }
  }
  position: { x: number; y: number }
}

/**
 * MeetingHoverTooltip
 * Appears near cursor on meeting hover; relies on fixed positioning with mouse coordinates.
 */
export default function MeetingHoverTooltip({ meeting, position }: MeetingHoverTooltipProps) {
  if (!meeting.details) return null
  const { details } = meeting
  return (
    <div
      className="meeting-hover-tooltip"
      style={{
        position: 'fixed',
        top: position.y + 10,
        left: position.x + 10,
        background: '#FFFFFF',
        border: '1px solid #E2E8F0',
        borderRadius: 8,
        padding: '10px 12px',
        boxShadow: '0 8px 18px -4px rgba(0,0,0,0.18)',
        fontSize: 12,
        lineHeight: 1.4,
        width: 220,
        zIndex: 9999,
        pointerEvents: 'none'
      }}
    >
      <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 4 }}>{meeting.title.replace(/\n/g, ' ')}</div>
      <div style={{ display: 'grid', gap: 2 }}>
        <div><strong>Time:</strong> {details.time}</div>
        <div><strong>Attendees:</strong> {details.attendees}</div>
        <div><strong>Organizer:</strong> {details.organizer}</div>
      </div>
    </div>
  )
}
