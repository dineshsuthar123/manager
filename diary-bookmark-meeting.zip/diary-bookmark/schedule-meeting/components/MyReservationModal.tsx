import React, { useState } from 'react'
import { Button, Table } from 'antd'
import { CloseOutlined, ArrowLeftOutlined } from '@ant-design/icons'

interface MyReservationModalProps {
    visible: boolean
    onClose: () => void
}

interface ReservationData {
    id: string
    status: 'Confirmed' | 'Pending' | 'Cancelled'
    topic: string
    place: string
    floor: string
    room: string
    date: string
    daysOfWeek: string
    time: string
    type: string
}

const mockReservations: ReservationData[] = [
    {
        id: '1',
        status: 'Confirmed',
        topic: 'DSM',
        place: 'Phoenix',
        floor: '3',
        room: 'London',
        date: 'July 23 2025',
        daysOfWeek: 'Wed, Thu, Fri',
        time: '11.00 to 11.30',
        type: 'General Meeting'
    },
    {
        id: '2',
        status: 'Confirmed',
        topic: 'DSM',
        place: 'Phoenix',
        floor: '3',
        room: 'London',
        date: 'July 23 2025',
        daysOfWeek: 'Wed, Thu, Fri',
        time: '11.00 to 11.30',
        type: 'General Meeting'
    },
    {
        id: '3',
        status: 'Confirmed',
        topic: 'DSM',
        place: 'Phoenix',
        floor: '3',
        room: 'London',
        date: 'July 23 2025',
        daysOfWeek: 'Wed, Thu, Fri',
        time: '11.00 to 11.30',
        type: 'General Meeting'
    }
]

export default function MyReservationModal({ visible, onClose }: MyReservationModalProps) {
    const columns = [
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            width: 100,
            render: (status: string) => (
                <span style={{ 
                    color: status === 'Confirmed' ? '#1890ff' : '#000',
                    fontWeight: '500'
                }}>
                    {status}
                </span>
            )
        },
        {
            title: 'Topic',
            dataIndex: 'topic',
            key: 'topic',
            width: 80
        },
        {
            title: 'Place',
            dataIndex: 'place',
            key: 'place',
            width: 80
        },
        {
            title: 'Floor',
            dataIndex: 'floor',
            key: 'floor',
            width: 60
        },
        {
            title: 'Room',
            dataIndex: 'room',
            key: 'room',
            width: 80
        },
        {
            title: 'Date',
            dataIndex: 'date',
            key: 'date',
            width: 120
        },
        {
            title: 'Days of Week',
            dataIndex: 'daysOfWeek',
            key: 'daysOfWeek',
            width: 120
        },
        {
            title: 'Time',
            dataIndex: 'time',
            key: 'time',
            width: 120
        },
        {
            title: 'Type',
            dataIndex: 'type',
            key: 'type',
            width: 140
        },
        {
            title: 'Modify',
            key: 'modify',
            width: 150,
            render: (record: ReservationData) => (
                <div style={{ display: 'flex', gap: '8px' }}>
                    <Button 
                        type="link" 
                        size="small"
                        style={{ 
                            color: '#1890ff',
                            padding: '0',
                            height: 'auto'
                        }}
                    >
                        Modify
                    </Button>
                    <Button 
                        type="link" 
                        size="small"
                        style={{ 
                            color: '#ff4d4f',
                            padding: '0',
                            height: 'auto'
                        }}
                    >
                        Cancel
                    </Button>
                </div>
            )
        }
    ]

    if (!visible) return null

    return (
        <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000
        }}>
            <div style={{
                width: '1200px',
                height: '700px',
                backgroundColor: '#FFFFFF',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
                display: 'flex',
                flexDirection: 'column',
                overflow: 'hidden'
            }}>
                {/* Header */}
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: '16px 24px',
                    borderBottom: '1px solid #f0f0f0',
                    backgroundColor: '#FFFFFF'
                }}>
                    <Button 
                        type="text" 
                        icon={<ArrowLeftOutlined />} 
                        onClick={onClose}
                        style={{ 
                            marginRight: '12px',
                            color: '#666'
                        }}
                    />
                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                    }}>
                        <div style={{
                            width: '20px',
                            height: '20px',
                            backgroundColor: '#4F46E5',
                            borderRadius: '4px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <span style={{ color: '#FFFFFF', fontSize: '12px', fontWeight: 'bold' }}>📅</span>
                        </div>
                        <span style={{
                            fontSize: '18px',
                            fontWeight: '600',
                            color: '#000000'
                        }}>
                            Book a Meeting Room
                        </span>
                    </div>
                </div>

                {/* Breadcrumb */}
                <div style={{
                    padding: '12px 24px',
                    fontSize: '14px',
                    color: '#666',
                    backgroundColor: '#fafafa',
                    borderBottom: '1px solid #f0f0f0'
                }}>
                    My Workspace &gt; Book a Meeting Room &gt; My Reservation
                </div>

                {/* Title */}
                <div style={{
                    padding: '16px 24px',
                    borderBottom: '1px solid #f0f0f0'
                }}>
                    <h2 style={{
                        margin: 0,
                        fontSize: '20px',
                        fontWeight: '600',
                        color: '#000000'
                    }}>
                        My Reservation Status
                    </h2>
                </div>

                {/* Table */}
                <div style={{
                    flex: 1,
                    padding: '0 24px 24px 24px',
                    overflow: 'auto'
                }}>
                    <Table 
                        columns={columns}
                        dataSource={mockReservations}
                        rowKey="id"
                        pagination={false}
                        size="middle"
                        style={{
                            marginTop: '16px'
                        }}
                        className="reservation-status-table"
                    />
                </div>
            </div>
        </div>
    )
}