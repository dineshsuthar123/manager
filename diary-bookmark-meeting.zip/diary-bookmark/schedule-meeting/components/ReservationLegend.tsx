import React from 'react'

interface ReservationLegendProps {}

export default function ReservationLegend() {
    const legendItems = [
        { color: '#FFFFFF', label: 'Reservation Possible', border: '#D0D5DD' },
        { color: '#FFD700', label: 'Waiting for Approval' },
        { color: '#009951', label: 'Complete Reservation' },
        { color: '#9C27B0', label: 'Video Conference', isIcon: true },
        { color: '#FF9800', label: 'Approval Required' },
        { color: '#4299E1', label: 'Auto Reservation', isIcon: true },
        { color: '#00C3D0', label: 'UC Conference' },
    ]

    return (
        <div className="reservation-legend">
            <h3>Reservation Status</h3>
            <div className="legend-items">
                {legendItems.map((item, index) => (
                    <div key={index} className="legend-item">
                        <div 
                            className={`legend-indicator ${item.isIcon ? 'icon' : 'circle'}`}
                            style={{ 
                                backgroundColor: item.color,
                                border: item.border ? `0.5px solid ${item.border}` : 'none'
                            }}
                        />
                        <span className="legend-label">{item.label}</span>
                    </div>
                ))}
            </div>
        </div>
    )
}