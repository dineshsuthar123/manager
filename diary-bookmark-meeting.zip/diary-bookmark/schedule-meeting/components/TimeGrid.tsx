import React, { useState } from 'react'
import MeetingHoverTooltip from './MeetingHoverTooltip'

interface TimeGridProps {
    onOpenMeetingModal?: () => void
}

interface Meeting {
    startTime: number
    duration: number
    title: string
    type: 'booked' | 'suggested' | 'video-conference' | 'available'
    color?: string
    details?: {
        time: string
        attendees: number
        organizer: string
    }
}

interface RoomData {
    floor: string
    name: string
    hasVideo: boolean
    hasAccessibility: boolean
    meetings: Meeting[]
}

export default function TimeGrid({ onOpenMeetingModal }: TimeGridProps) {
    const [hoveredMeeting, setHoveredMeeting] = useState<Meeting | null>(null)
    const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

    const timeSlots = [
        '7 AM', '8 AM', '9 AM', '10 AM', '11 AM', '12 AM', 
        '13 PM', '14 PM', '15 PM', '16 PM', '17 PM', '18 PM', 
        '19 PM', '20 PM', '21 PM', '22 PM'
    ]

    const rooms: RoomData[] = [
        {
            floor: 'Phoenix, Floor 1',
            name: 'Ajanta',
            hasVideo: true,
            hasAccessibility: true,
            meetings: [
                { 
                    startTime: 3, 
                    duration: 1, 
                    title: '10.00 AM\nGTEC DSM', 
                    type: 'booked', 
                    color: '#DDF2FD'
                },
                { 
                    startTime: 9, 
                    duration: 3, 
                    title: '16.00 AM', 
                    type: 'booked', 
                    color: '#DDF2FD'
                }
            ]
        },
        {
            floor: 'Phoenix, Floor 2',
            name: 'Hampi',
            hasVideo: false,
            hasAccessibility: true,
            meetings: []
        },
        {
            floor: 'Phoenix, Floor 3',
            name: 'Incheon',
            hasVideo: true,
            hasAccessibility: true,
            meetings: [
                { 
                    startTime: 2, 
                    duration: 1, 
                    title: '8.00 AM\nReview', 
                    type: 'booked', 
                    color: '#DDF2FD',
                    details: {
                        time: '11.00 pm to 12.00 pm',
                        attendees: 6,
                        organizer: 'Isha Kumar'
                    }
                }
            ]
        },
        {
            floor: 'Phoenix, Floor 4',
            name: 'Ulsan',
            hasVideo: false,
            hasAccessibility: true,
            meetings: []
        }
    ]

    const handleMeetingHover = (meeting: Meeting, event: React.MouseEvent) => {
        setHoveredMeeting(meeting)
        setMousePosition({ x: event.clientX, y: event.clientY })
    }

    const handleMeetingLeave = () => {
        setHoveredMeeting(null)
    }

    return (
        <>
            <div className="time-grid">
                <div className="grid-header">
                    <div className="search-results">
                        <span className="results-text">Showing search results for Phoenix, floor 3</span>
                        <span className="instruction-text">Drag to create meeting at desired room</span>
                    </div>
                </div>

                <div className="time-header">
                    <div className="building-floor-header">Building & Floor</div>
                    <div className="rooms-title">Rooms</div>
                    {timeSlots.map((time, index) => (
                        <div key={index} className="time-slot">
                            {time}
                        </div>
                    ))}
                </div>

                <div className="rooms-container">
                    {rooms.map((room, roomIndex) => (
                        <div key={roomIndex} className="room-row">
                            <div className="building-floor-cell">
                                {room.floor}
                            </div>
                            <div className="room-name">
                                <span>{room.name}</span>
                                <div className="room-icons">
                                    {room.hasVideo && <span className="icon">📺</span>}
                                    {room.hasAccessibility && <span className="icon">♿</span>}
                                </div>
                            </div>
                            
                            <div className="room-timeline">
                                {Array.from({ length: 16 }, (_, slotIndex) => (
                                    <div 
                                        key={slotIndex} 
                                        className={`time-cell ${slotIndex === 0 ? 'first' : ''} ${slotIndex === 15 ? 'last' : ''}`}
                                        onClick={() => {
                                            // Check if this slot is free (no meetings at this time)
                                            const hasMeeting = room.meetings.some(meeting => 
                                                slotIndex >= meeting.startTime && slotIndex < meeting.startTime + meeting.duration
                                            )
                                            if (!hasMeeting && onOpenMeetingModal) {
                                                onOpenMeetingModal()
                                            }
                                        }}
                                    >
                                        {room.meetings.map((meeting, meetingIndex) => {
                                            if (meeting.startTime === slotIndex) {
                                                return (
                                                    <div 
                                                        key={meetingIndex}
                                                        className={`meeting-block ${meeting.type}`}
                                                        style={{
                                                            width: `${meeting.duration * 75}px`,
                                                            backgroundColor: meeting.color
                                                        }}
                                                        onMouseEnter={(e) => meeting.details && handleMeetingHover(meeting, e)}
                                                        onMouseLeave={handleMeetingLeave}
                                                    >
                                                        {meeting.title && (
                                                            <div className="meeting-text">
                                                                {meeting.title}
                                                            </div>
                                                        )}
                                                    </div>
                                                )
                                            }
                                            return null
                                        })}
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            {hoveredMeeting && hoveredMeeting.details && (
                <MeetingHoverTooltip
                    meeting={hoveredMeeting}
                    position={mousePosition}
                />
            )}
        </>
    )
}