# Schedule Meeting - Meeting Room Booking System

A complete meeting room booking interface built with React and TypeScript, featuring pixel-perfect design implementation based on the provided specifications.

## 🚀 Features

- **Meeting Room Search & Filtering**: Filter by building, floor, date, time, seats, conference room type, and supplies
- **Interactive Time Grid**: Visual timeline showing room availability and bookings
- **Reservation Status Legend**: Clear indicators for different reservation states
- **Responsive Navigation**: Full navigation bar with user profile and quick actions
- **Pixel-Perfect Design**: Exact implementation of the provided design specifications

## 📁 Project Structure

```
schedule-meeting/
├── components/
│   ├── TopNav.tsx              # Navigation bar component
│   ├── SearchFilters.tsx       # Search and filter controls
│   ├── ReservationLegend.tsx   # Status legend component
│   └── TimeGrid.tsx           # Room timeline grid
├── BookMeetingRoom.tsx        # Main component
├── App.tsx                    # App wrapper
├── main.tsx                   # React entry point
├── index.html                 # HTML template
├── meeting-room.css           # Complete styling
└── README.md                  # This file
```

## 🎨 Design Implementation

### Layout Specifications
- **Canvas Size**: 1440px × 1024px
- **Background**: #F5F6FA
- **Font Family**: Samsung InterFace (fallback: Inter)

### Key Components

#### 1. TopNav
- Full-width navigation with brand, workspace tabs, and user profile
- Search functionality and quick action buttons
- Notification badges and user avatar

#### 2. Search Filters
- Building & Floor selection with dropdowns
- Date picker and time range selectors
- Seats, conference room, and supplies filters
- Primary search button

#### 3. Reservation Legend
- Color-coded status indicators
- Different reservation states (Available, Waiting, Complete, etc.)
- Video conference and auto-reservation indicators

#### 4. Time Grid
- 16-hour timeline from 7 AM to 22 PM
- Room rows with availability visualization
- Meeting blocks with different styling
- Interactive tooltips for room information

## 🔧 Technical Features

- **React 18** with TypeScript
- **Ant Design** components for UI consistency
- **CSS Custom Properties** for theming
- **Responsive Design** considerations
- **Component-based Architecture** for maintainability

## 🎯 Color Scheme

- **Primary**: #38AEE0 (Blue)
- **Background**: #F5F6FA (Light Gray)
- **Text Primary**: #202224 (Dark Gray)
- **Text Secondary**: #606060 (Medium Gray)
- **Success**: #009951 (Green)
- **Warning**: #FFD700 (Yellow)
- **Purple**: #9F7AEA (Purple for suggested meetings)

## 📱 Usage

### Installation
```bash
npm install antd react react-dom @types/react @types/react-dom
```

### Running the Application
1. Ensure all dependencies are installed
2. Navigate to the schedule-meeting directory
3. Run with your preferred React development server
4. Access at your local development URL

### Integration
This component can be integrated into larger applications by importing the `BookMeetingRoom` component and ensuring the CSS styles are loaded.

## 🎨 Styling Notes

- Uses absolute positioning for pixel-perfect layout matching
- Implements gradients and shadows as specified in the design
- Responsive considerations for different screen sizes
- Hover states and interactive elements included

## 🔄 State Management

The components include basic state management for:
- Filter selections
- Time slot interactions
- Meeting block displays
- Tooltip visibility

## 📊 Data Structure

The time grid supports:
- Room names and metadata
- Meeting start times and durations
- Different meeting types (booked, suggested, video conference)
- Custom styling per meeting type

## 🚀 Future Enhancements

- Real-time booking functionality
- Backend API integration
- Drag-and-drop meeting creation
- Calendar synchronization
- Email notifications
- Mobile responsiveness improvements

## 📄 License

This project is part of the Nest workspace management system.