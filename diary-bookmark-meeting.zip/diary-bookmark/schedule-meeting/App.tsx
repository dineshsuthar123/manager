import React from 'react'
import BookMeetingRoom from './BookMeetingRoom'
import './meeting-room.css'

function App() {
    return (
        <div className="App">
            <BookMeetingRoom />
        </div>
    )
}

export default App