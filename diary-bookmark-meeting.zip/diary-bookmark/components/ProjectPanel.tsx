import React from 'react'
import { ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

function CheckIcon() {
    return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" fill="#4ADE80" />
            <path d="m9 12 2 2 4-4" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    )
}

function ClockIcon() {
    return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#D1D5DB" strokeWidth="2" />
            <path d="M12 6v6l4 2" stroke="#D1D5DB" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    )
}

function ProgressRing() {
    return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#E5E7EB" strokeWidth="2" />
            <circle
                cx="12"
                cy="12"
                r="10"
                stroke="#10B981"
                strokeWidth="2"
                strokeLinecap="round"
                fill="none"
                strokeDasharray="62.83"
                strokeDashoffset="31.415"
                transform="rotate(-90 12 12)"
            />
        </svg>
    )
}

function CalendarIcon() {
    return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <rect x="3" y="4" width="18" height="18" rx="2" ry="2" stroke="#9CA3AF" strokeWidth="2" />
            <line x1="16" y1="2" x2="16" y2="6" stroke="#9CA3AF" strokeWidth="2" />
            <line x1="8" y1="2" x2="8" y2="6" stroke="#9CA3AF" strokeWidth="2" />
            <line x1="3" y1="10" x2="21" y2="10" stroke="#9CA3AF" strokeWidth="2" />
        </svg>
    )
}

export default function ProjectPanel() {
    return (
        <div className="project-card">
            <div className="proj-head">
                <div className="proj-left">
                    <div className="proj-title font-sharp">Project - Mobile App Development</div>
                    <div className="proj-stage-flow">
                        <div className="stage-item completed">
                            <CheckIcon />
                            <span>Planning</span>
                        </div>
                        <div className="stage-connector completed"></div>
                        <div className="stage-item completed">
                            <CheckIcon />
                            <span>Design</span>
                        </div>
                        <div className="stage-connector active"></div>
                        <div className="stage-item active">
                            <ProgressRing />
                            <span>Development</span>
                        </div>
                        <div className="stage-connector"></div>
                        <div className="stage-item">
                            <ClockIcon />
                            <span>Testing</span>
                        </div>
                    </div>
                </div>
                <div className="proj-launch">
                    <div className="launch-left">
                        <img className="launch-img" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODQiIGhlaWdodD0iODQiIHZpZXdCb3g9IjAgMCA4NCA4NCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9Ijg0IiBoZWlnaHQ9Ijg0IiByeD0iOCIgZmlsbD0iIzMzNzFGRiIvPgo8cGF0aCBkPSJNNDIgMjBMMzQgMjhMNDIgMzZMNTAgMjhMNDIgMjBaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNNDIgMzZMNDIgNjQiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMyIvPgo8cGF0aCBkPSJNMzQgNTJMMzggNTZMNDIgNTJMNDYgNTZMNTAgNTIiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMiIgZmlsbD0ibm9uZSIvPgo8L3N2Zz4K" alt="Rocket launch" />
                    </div>
                    <div className="launch-right">
                        <div className="launch-label">Launch Date</div>
                        <div className="launch-date font-sharp">Friday December 16</div>
                        <div className="launch-leftdays font-sharp">212 Days Left</div>
                    </div>
                </div>
            </div>

            <div className="proj-progress">
                <div className="proj-progress-head">
                    <span className="font-sharp">16/36 Task Completed</span>
                    <span className="on-track">On Track</span>
                </div>
                <div className="proj-bar">
                    <div className="proj-bar-fill pct-45" />
                </div>
                <div className="proj-deltas">
                    <span className="delta-left">8.5% Up from yesterday</span>
                    <span className="delta-right">8.5% Up from yesterday</span>
                </div>
                <div className="proj-meta-row">
                    <div className="proj-completion">45% Project Complete</div>
                    <div className="proj-date">
                        <CalendarIcon />
                        <span>28 March</span>
                    </div>
                </div>
                <div className="proj-avatars">
                    <div className="avatar-stack">
                        {Array.from({ length: 7 }).map((_, i) => (
                            <img key={i} className="avatar" src={`https://i.pravatar.cc/48?img=${i + 1}`} alt={`Team member ${i + 1}`} />
                        ))}
                    </div>
                    <span className="teamhub-sub">12 Team Members</span>
                </div>
            </div>

            <div className="proj-team">
                <div className="proj-team-title font-sharp">Team Task Progress</div>
                <div className="proj-cards">
                    {[
                        { n: 'Sarah K', v: 2, t: 8, color: '#EF3826' },
                        { n: 'Vishal', v: 3, t: 8, color: '#FF9500' },
                        { n: 'Jena', v: 4, t: 8, color: '#009951' },
                        { n: 'Amar', v: 6, t: 8, color: '#009951' },
                        { n: 'Sima', v: 3, t: 8, color: '#FF9500' },
                        { n: 'Kumar', v: 4, t: 8, color: '#009951' },
                    ].map((m, i) => {
                        const percent = Math.max(0, Math.min(100, Math.round((m.v / m.t) * 100)))
                        const data = [
                            { name: 'progress', value: percent },
                            { name: 'remaining', value: 100 - percent },
                        ]
                        return (
                            <div key={i} className="mini-card">
                                <div className="mini-name">{m.n}</div>
                                <div style={{ width: 64, height: 64, position: 'relative', overflow: 'hidden' }}>
                                    <ResponsiveContainer width="100%" height="100%">
                                        <PieChart>
                                            <Pie
                                                data={data}
                                                dataKey="value"
                                                innerRadius={20}
                                                outerRadius={28}
                                                startAngle={90}
                                                endAngle={-270}
                                                cornerRadius={10}
                                                stroke="none"
                                            >
                                                <Cell key="p" fill={m.color} />
                                                <Cell key="r" fill="#E8E1FF" />
                                            </Pie>
                                        </PieChart>
                                    </ResponsiveContainer>
                                    <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, color: '#202224' }}>
                                        {m.v}/{m.t}
                                    </span>
                                </div>
                            </div>
                        )
                    })}
                </div>
                <div className="proj-pager">
                    <span className="pager-dot is-active" />
                    <span className="pager-dot" />
                </div>
            </div>
        </div>
    )
}