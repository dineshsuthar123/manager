import React from 'react'

type Card = {
    key: string
    title: string
    count: number | string
    critical?: string
    extra?: string
    variant: 'green' | 'cyan' | 'lilac' | 'violet'
    icon?: React.ReactNode
}

const IconTask = () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden>
        <path d="M4 6a2 2 0 012-2h4l2 2h6a2 2 0 012 2v10a2 2 0 01-2 2H6a2 2 0 01-2-2V6z" stroke="#16A34A" strokeWidth="1.5" />
        <path d="M8 12l2 2 4-4" stroke="#16A34A" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
)

const IconBug = () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden>
        <path d="M9 9h6a4 4 0 014 4v3a4 4 0 01-4 4H9a4 4 0 01-4-4v-3a4 4 0 014-4z" fill="#79B4C8" />
        <path d="M8 6h8" stroke="#79B4C8" strokeWidth="1.5" strokeLinecap="round" />
        <path d="M6 12H4m16 0h-2M7 16H4m16 0h-3" stroke="#79B4C8" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
)

const IconPR = () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden>
        <path d="M7 5a2 2 0 110 4 2 2 0 010-4zm0 10a2 2 0 110 4 2 2 0 010-4zM17 5a2 2 0 110 4 2 2 0 010-4z" fill="#8B5CF6" />
        <path d="M7 9v6m8-6c0 2.761-2.239 5-5 5H7" stroke="#8B5CF6" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
)

const IconCode = () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden>
        <path d="M9 8l-4 4 4 4M15 8l4 4-4 4" stroke="#8B5CF6" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
)

const cards: Card[] = [
    { key: 'tasks', title: 'TASK IN PROGRESS', count: 4, critical: '1 critical', extra: '2 New', variant: 'green', icon: <IconTask /> },
    { key: 'defects', title: 'OPEN DEFECTS', count: 2, critical: '1 critical', variant: 'cyan', icon: <IconBug /> },
    { key: 'review', title: 'PENDING REVIEW', count: 1, critical: '1 critical', variant: 'lilac', icon: <IconPR /> },
    { key: 'commits', title: 'CODE COMMITS', count: 1, critical: '1 critical', variant: 'violet', icon: <IconCode /> },
]

export default function TaskOverviewRow() {
    return (
        <div className="overview-row">
            {cards.map((c) => (
                <div key={c.key} className={`overview-card is-${c.variant}`}>
                    <div className="overview-icon">{c.icon}</div>
                    <div className="overview-body">
                        <div className="overview-title">{c.title}</div>
                        <div className="overview-metrics">
                            <div className="overview-count">{c.count}</div>
                            <div className="overview-sub">
                                {c.critical && <span className="danger">{c.critical}</span>}
                                {c.extra && <span className="extra">{c.extra}</span>}
                            </div>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    )
}