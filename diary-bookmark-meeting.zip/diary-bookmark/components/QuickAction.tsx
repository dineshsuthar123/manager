import React, { useState } from 'react';

const QuickAction: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'smart-collections' | 'shared' | 'all-bookmarks'>('smart-collections');
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const handleClose = () => {
    setIsVisible(false);
  };

  const handleAddBookmark = () => {
    // Add bookmark functionality
  };

  const containerStyle: React.CSSProperties = {
    position: 'relative',
    width: '320px',
    height: 'auto',
    minHeight: 'auto',
    background: 'linear-gradient(171.77deg, #DBFBFF -6.17%, #E5F8FF 25.06%, #E4DAFF 84.43%)',
    border: '0.5px solid #BBE8F0',
    borderRadius: '10px',
    boxSizing: 'border-box',
    overflow: 'hidden',
    fontFamily: 'Samsung InterFace, sans-serif',
  };

  const headerStyle: React.CSSProperties = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '16px',
    position: 'relative',
  };

  const titleStyle: React.CSSProperties = {
    fontWeight: 700,
    fontSize: '14px',
    lineHeight: '17px',
    letterSpacing: '1px',
    color: '#333333',
    margin: 0,
  };

  const headerActionsStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  };

  const addBtnStyle: React.CSSProperties = {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontWeight: 700,
    fontSize: '12px',
    color: '#38AEE0',
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
  };

  const addIconStyle: React.CSSProperties = {
    width: '16px',
    height: '16px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: '#38AEE0',
    color: 'white',
    borderRadius: '50%',
    fontSize: '12px',
  };

  const closeBtnStyle: React.CSSProperties = {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    width: '16px',
    height: '16px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  };

  const searchContainerStyle: React.CSSProperties = {
    padding: '0 16px 16px',
  };

  const searchInputStyle: React.CSSProperties = {
    width: '100%',
    height: '27px',
    background: '#FFFFFF',
    border: 'none',
    borderRadius: '8px',
    padding: '0 14px',
    fontSize: '12px',
    color: '#606060',
    boxSizing: 'border-box',
  };

  const navTabsStyle: React.CSSProperties = {
    display: 'flex',
    padding: '0 16px',
    borderBottom: '0.5px solid #D9D9D9',
    position: 'relative',
  };

  const getNavTabStyle = (isActive: boolean): React.CSSProperties => ({
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: isActive ? 700 : 400,
    color: '#333333',
    padding: '8px 16px 12px 0',
    marginRight: '16px',
    position: 'relative',
  });

  const tabContentStyle: React.CSSProperties = {
    padding: '16px',
    height: 'auto',
    overflowY: 'auto',
  };

  const sectionStyle: React.CSSProperties = {
    marginBottom: '24px',
  };

  const sectionHeaderStyle: React.CSSProperties = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '12px',
  };

  const sectionTitleStyle: React.CSSProperties = {
    fontWeight: 700,
    fontSize: '14px',
    color: '#333333',
    margin: 0,
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  };

  const seeAllStyle: React.CSSProperties = {
    fontSize: '12px',
    fontWeight: 700,
    color: '#38AEE0',
    cursor: 'pointer',
  };

  const bookmarkGridStyle: React.CSSProperties = {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 1fr)',
    gap: '16px',
    marginBottom: '16px',
  };

  const bookmarkItemStyle: React.CSSProperties = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '8px',
  };

  const getBookmarkIconStyle = (type: string): React.CSSProperties => {
    const baseStyle: React.CSSProperties = {
      width: '36px',
      height: '36px',
      borderRadius: '8px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: 700,
      fontSize: '19px',
      color: '#FFFFFF',
    };

    switch (type) {
      case 'calendar':
        return { ...baseStyle, background: 'linear-gradient(135.64deg, #36A8DE 30.04%, #9BCDFF 99.45%)' };
      case 'hr-portal':
        return { ...baseStyle, background: 'linear-gradient(135.64deg, #A17DFC 18.89%, #D8CCF4 99.45%)' };
      case 'hr-portal-2':
        return { ...baseStyle, background: 'linear-gradient(132.49deg, #00C3D0 2.01%, #4FA0CA 97.99%)' };
      case 'mail':
        return { ...baseStyle, background: 'linear-gradient(135.64deg, #FFCA8B 16.24%, #FEF9C3 99.45%)', color: '#FF9500' };
      default:
        return baseStyle;
    }
  };

  const bookmarkLabelStyle: React.CSSProperties = {
    fontSize: '12px',
    color: '#333333',
    textAlign: 'center',
  };

  return (
    <div style={containerStyle}>
      {/* Header */}
      <div style={headerStyle}>
        <h2 style={titleStyle}>Quick Action</h2>
        <div style={headerActionsStyle}>
          <button style={addBtnStyle} onClick={handleAddBookmark}>
            <span style={addIconStyle}>+</span>
            Add
          </button>
          <button style={closeBtnStyle} onClick={handleClose}>
            <span style={{color: '#606060', fontSize: '14px'}}>×</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div style={searchContainerStyle}>
        <input 
          type="text" 
          placeholder="Search" 
          style={searchInputStyle}
        />
      </div>

      {/* Navigation Tabs */}
      <div style={navTabsStyle}>
        <button 
          style={getNavTabStyle(activeTab === 'all-bookmarks')}
          onClick={() => setActiveTab('all-bookmarks')}
        >
          All Bookmarks
          {activeTab === 'all-bookmarks' && (
            <div style={{
              position: 'absolute',
              bottom: '-1px',
              left: 0,
              right: '16px',
              height: '2px',
              background: '#38AEE0',
            }}></div>
          )}
        </button>
        <button 
          style={getNavTabStyle(activeTab === 'smart-collections')}
          onClick={() => setActiveTab('smart-collections')}
        >
          Smart Collections
          {activeTab === 'smart-collections' && (
            <div style={{
              position: 'absolute',
              bottom: '-1px',
              left: 0,
              right: '16px',
              height: '2px',
              background: '#38AEE0',
            }}></div>
          )}
        </button>
        <button 
          style={getNavTabStyle(activeTab === 'shared')}
          onClick={() => setActiveTab('shared')}
        >
          Shared
          {activeTab === 'shared' && (
            <div style={{
              position: 'absolute',
              bottom: '-1px',
              left: 0,
              right: '16px',
              height: '2px',
              background: '#38AEE0',
            }}></div>
          )}
        </button>
      </div>

      {/* Content based on active tab */}
      {activeTab === 'smart-collections' && (
        <div style={tabContentStyle}>
          {/* Frequently Used Section */}
          <div style={sectionStyle}>
            <div style={sectionHeaderStyle}>
              <h3 style={sectionTitleStyle}>Frequently Used</h3>
              <span style={seeAllStyle}>See All</span>
            </div>
            <div style={bookmarkGridStyle}>
              <div style={bookmarkItemStyle}>
                <span style={getBookmarkIconStyle('calendar')}>C</span>
                <span style={bookmarkLabelStyle}>Calendar</span>
              </div>
              <div style={bookmarkItemStyle}>
                <span style={getBookmarkIconStyle('hr-portal')}>H</span>
                <span style={bookmarkLabelStyle}>HR Portal</span>
              </div>
              <div style={bookmarkItemStyle}>
                <span style={getBookmarkIconStyle('hr-portal-2')}>H</span>
                <span style={bookmarkLabelStyle}>HR Portal</span>
              </div>
              <div style={bookmarkItemStyle}>
                <span style={getBookmarkIconStyle('mail')}>M</span>
                <span style={bookmarkLabelStyle}>Mail</span>
              </div>
            </div>
          </div>

          {/* Smart Suggestion Section */}
          <div style={sectionStyle}>
            <div style={sectionHeaderStyle}>
              <h3 style={sectionTitleStyle}>
                <span style={{fontSize: '16px'}}>💡</span>
                Smart Suggestion
              </h3>
            </div>
            <p style={{fontSize: '12px', color: '#333333', margin: '0 0 12px 0'}}>Based on your Recent activity</p>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px'}}>
              <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px', minHeight: '102px', position: 'relative'}}>
                <div style={{width: '100%', height: '50px', background: '#BBE8F0', borderRadius: '8px 8px 0 0', margin: '-16px -16px 12px -16px'}}></div>
                <h4 style={{fontSize: '12px', fontWeight: 700, color: '#333333', margin: '0 0 4px 0'}}>Reach Development</h4>
                <p style={{fontSize: '12px', color: '#606060', margin: 0}}>Article</p>
              </div>
              <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px', minHeight: '102px', position: 'relative'}}>
                <div style={{width: '100%', height: '50px', background: '#BBE8F0', borderRadius: '8px 8px 0 0', margin: '-16px -16px 12px -16px'}}></div>
                <h4 style={{fontSize: '12px', fontWeight: 700, color: '#333333', margin: '0 0 4px 0'}}>Design System</h4>
                <p style={{fontSize: '12px', color: '#606060', margin: 0}}>Article</p>
              </div>
            </div>
          </div>

          {/* Recently Added Section */}
          <div style={sectionStyle}>
            <div style={sectionHeaderStyle}>
              <h3 style={sectionTitleStyle}>Recently Added</h3>
              <span style={seeAllStyle}>See All</span>
            </div>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px'}}>
              <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px', minHeight: '120px'}}>
                <div style={{width: '100%', height: '50px', background: '#BBE8F0', borderRadius: '8px 8px 0 0', margin: '-16px -16px 12px -16px'}}></div>
                <h4 style={{fontSize: '12px', fontWeight: 700, color: '#333333', margin: '12px 0 8px 0'}}>Product Roadmap</h4>
                <div style={{display: 'flex', flexDirection: 'column', gap: '4px'}}>
                  <span style={{fontSize: '12px', color: '#4880FF'}}>📁 Check after release</span>
                  <span style={{fontSize: '12px', color: '#606060'}}>2 hrs ago</span>
                </div>
              </div>
              <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px', minHeight: '120px'}}>
                <div style={{width: '100%', height: '50px', background: '#BBE8F0', borderRadius: '8px 8px 0 0', margin: '-16px -16px 12px -16px'}}></div>
                <h4 style={{fontSize: '12px', fontWeight: 700, color: '#333333', margin: '12px 0 8px 0'}}>Brand Guidelines</h4>
                <div style={{display: 'flex', flexDirection: 'column', gap: '4px'}}>
                  <span style={{fontSize: '12px', color: '#4880FF'}}>📁 For Onboarding</span>
                  <span style={{fontSize: '12px', color: '#606060'}}>Yesterday</span>
                </div>
              </div>
            </div>
          </div>

          {/* Time-Sensitive Section */}
          <div style={sectionStyle}>
            <div style={sectionHeaderStyle}>
              <h3 style={sectionTitleStyle}>Time-Sensitive</h3>
              <span style={seeAllStyle}>See All</span>
            </div>
            <div style={{display: 'flex', flexDirection: 'column', gap: '16px'}}>
              <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px'}}>
                <h4 style={{fontSize: '14px', fontWeight: 700, color: '#333333', margin: '0 0 8px 0'}}>Team Meeting Notes</h4>
                <div style={{display: 'flex', flexDirection: 'column', gap: '4px', marginBottom: '12px'}}>
                  <span style={{color: '#4299E1', fontSize: '12px'}}>👥 Shared</span>
                  <span style={{color: '#333333', fontSize: '12px'}}>⏰ Reminder in 2 days</span>
                </div>
                <div style={{display: 'flex', gap: '8px'}}>
                  <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', color: '#4880FF'}}>📂 Open</button>
                  <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', color: '#4880FF'}}>📤 Share</button>
                </div>
              </div>
              <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px'}}>
                <h4 style={{fontSize: '14px', fontWeight: 700, color: '#333333', margin: '0 0 8px 0'}}>Quarterly Report</h4>
                <div style={{display: 'flex', flexDirection: 'column', gap: '4px', marginBottom: '12px'}}>
                  <span style={{color: '#BA1A1A', fontSize: '12px'}}>⚠️ Expires in 5 days</span>
                </div>
                <div style={{display: 'flex', gap: '8px'}}>
                  <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', color: '#4880FF'}}>📂 Open</button>
                  <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', color: '#4880FF'}}>📤 Share</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'shared' && (
        <div style={{...tabContentStyle, background: '#E9F9FF', borderRadius: '10px', padding: '16px', margin: '-16px', minHeight: 'calc(100vh - 200px)'}}>
          <div style={{display: 'flex', gap: '16px', marginBottom: '24px', borderBottom: '0.5px solid #D9D9D9', paddingBottom: '12px'}}>
            <button style={{background: 'none', border: 'none', fontSize: '12px', color: '#202224', cursor: 'pointer', position: 'relative'}}>
              Shared with you
              <div style={{position: 'absolute', bottom: '-12px', left: 0, right: 0, height: '2px', background: '#38AEE0'}}></div>
            </button>
            <button style={{background: 'none', border: 'none', fontSize: '12px', color: '#202224', cursor: 'pointer'}}>You Shared</button>
          </div>
          
          <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px', marginBottom: '16px'}}>
            <h3 style={{fontSize: '14px', fontWeight: 700, color: '#000000', margin: '0 0 8px 0'}}>Must-read Resources</h3>
            <p style={{fontSize: '12px', color: '#606060', margin: '0 0 12px 0'}}>Shared by Alex for the design team</p>
            <div style={{display: 'flex', flexDirection: 'column', gap: '8px'}}>
              <span style={{fontSize: '12px', color: '#202224'}}>📄 Design Trends</span>
              <span style={{fontSize: '12px', color: '#202224'}}>📄 2025 UX Research guidelines</span>
            </div>
          </div>

          <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px', marginBottom: '16px'}}>
            <h3 style={{fontSize: '14px', fontWeight: 700, color: '#000000', margin: '0 0 8px 0'}}>Onboarding Material</h3>
            <p style={{fontSize: '12px', color: '#606060', margin: '0 0 12px 0'}}>⚠️ Expires in 3 days</p>
            <div style={{display: 'flex', gap: '8px'}}>
              <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', color: '#4880FF', cursor: 'pointer'}}>Welcome Guide</button>
              <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', color: '#4880FF', cursor: 'pointer'}}>Team Structure</button>
            </div>
          </div>

          <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px', marginBottom: '16px'}}>
            <h3 style={{fontSize: '14px', fontWeight: 700, color: '#000000', margin: '0 0 8px 0'}}>Product Dashboard</h3>
            <p style={{fontSize: '12px', color: '#606060', margin: '0 0 12px 0'}}>⚠️ Expires in 3 days</p>
            <div style={{background: '#F3F9FF', border: '1px solid #B9DCFF', borderRadius: '4px', padding: '12px', fontSize: '12px', color: '#606060', margin: '12px 0'}}>
              Check again after release on Friday. Need to validate metrics
            </div>
            <button style={{background: '#DFEEFC', border: 'none', borderRadius: '12px', padding: '6px 12px', fontSize: '12px', color: '#4880FF', cursor: 'pointer'}}>Extend 1 week</button>
          </div>

          <div style={{marginBottom: '16px'}}>
            <h3 style={{fontSize: '14px', fontWeight: 700, color: '#333333', margin: '0 0 16px 0'}}>Time-Sensitive</h3>
            <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px', marginBottom: '16px'}}>
              <h4 style={{fontSize: '14px', fontWeight: 700, color: '#333333', margin: '0 0 8px 0'}}>Team Meeting Notes</h4>
              <span style={{color: '#4299E1', fontSize: '12px'}}>👥 Shared</span>
              <span style={{color: '#333333', fontSize: '12px', display: 'block'}}>⏰ Reminder in 2 days</span>
              <div style={{display: 'flex', gap: '8px', marginTop: '12px'}}>
                <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', color: '#4880FF'}}>📂 Open</button>
                <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', color: '#4880FF'}}>📤 Share</button>
              </div>
            </div>
            <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px'}}>
              <h4 style={{fontSize: '14px', fontWeight: 700, color: '#333333', margin: '0 0 8px 0'}}>Quarterly Report</h4>
              <span style={{color: '#BA1A1A', fontSize: '12px'}}>⚠️ Expires in 5 days</span>
              <div style={{display: 'flex', gap: '8px', marginTop: '12px'}}>
                <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', color: '#4880FF'}}>📂 Open</button>
                <button style={{background: '#E0F6FF', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', color: '#4880FF'}}>📤 Share</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'all-bookmarks' && (
        <div style={{...tabContentStyle, background: '#E9F9FF', borderRadius: '10px', padding: '16px', margin: '-16px', height: 'auto', minHeight: 'auto'}}>
          <div style={{marginBottom: '24px'}}>
            <div style={sectionHeaderStyle}>
              <h3 style={sectionTitleStyle}>Categories</h3>
              <button style={{background: 'none', border: 'none', color: '#38AEE0', fontSize: '12px', cursor: 'pointer'}}>+ Add</button>
              <span style={seeAllStyle}>See All</span>
            </div>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '16px'}}>
              <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px'}}>
                <div style={{width: '48px', height: '48px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px', background: '#DFEEFC', border: '1px solid #2196F3'}}>🎓</div>
                <span style={{fontSize: '12px', color: '#202224'}}>Learning</span>
              </div>
              <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px'}}>
                <div style={{width: '48px', height: '48px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px', background: '#E8DEF8'}}>🔧</div>
                <span style={{fontSize: '12px', color: '#202224'}}>Daily Tools</span>
              </div>
              <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px'}}>
                <div style={{width: '48px', height: '48px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px', background: '#FEF9C3'}}>⚡</div>
                <span style={{fontSize: '12px', color: '#202224'}}>Quick Access</span>
              </div>
              <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px'}}>
                <div style={{width: '48px', height: '48px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px', background: '#DDF9C8'}}>⚙️</div>
                <span style={{fontSize: '12px', color: '#202224'}}>Dev.</span>
              </div>
            </div>
          </div>

          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px'}}>
            <p style={{fontSize: '12px', color: '#202224', margin: 0}}>Drag and drop bookmarks to create folders</p>
            <button style={{background: 'none', border: 'none', fontSize: '16px', cursor: 'pointer'}}>📁</button>
          </div>

          <div style={{background: '#FFFFFF', borderRadius: '8px', padding: '16px'}}>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px', marginBottom: '24px'}}>
              <div style={{background: '#F3F9FF', border: '1px solid #E0F6FF', borderRadius: '8px', padding: '16px', minHeight: '118px'}}>
                <div style={{display: 'flex', gap: '12px', marginBottom: '8px'}}>
                  <span style={{width: '20px', height: '20px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '14px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #36A8DE 30.04%, #9BCDFF 99.45%)'}}>C</span>
                  <span style={{width: '20px', height: '20px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '14px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #99D7EC 30.04%, #9BCDFF 99.45%)'}}>A</span>
                  <span style={{width: '20px', height: '20px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '14px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #4CB3C1 30.04%, #9BCDFF 99.45%)'}}>X</span>
                </div>
                <div style={{display: 'flex', gap: '12px'}}>
                  <span style={{fontSize: '8px', color: '#606060'}}>Leo..</span>
                  <span style={{fontSize: '8px', color: '#606060'}}>Ne..</span>
                  <span style={{fontSize: '8px', color: '#606060'}}>Ne..</span>
                </div>
              </div>
              <div style={{background: '#F3F9FF', border: '1px solid #E0F6FF', borderRadius: '8px', padding: '16px', minHeight: '118px'}}>
                <div style={{display: 'flex', gap: '12px', marginBottom: '8px'}}>
                  <span style={{width: '20px', height: '20px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '14px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #4880FF 30.04%, #9BCDFF 99.45%)'}}>B</span>
                  <span style={{width: '20px', height: '20px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '14px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #01A8D2 30.04%, #9BCDFF 99.45%)'}}>C</span>
                  <span style={{width: '20px', height: '20px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '14px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #36A8DE 30.04%, #9BCDFF 99.45%)'}}>D</span>
                </div>
                <div style={{display: 'flex', gap: '12px'}}>
                  <span style={{fontSize: '8px', color: '#606060'}}>Leo..</span>
                  <span style={{fontSize: '8px', color: '#606060'}}>Ne..</span>
                  <span style={{fontSize: '8px', color: '#606060'}}>Ne..</span>
                </div>
              </div>
            </div>

            <div style={{textAlign: 'center'}}>
              <div style={{display: 'flex', justifyContent: 'center', gap: '16px', marginBottom: '8px'}}>
                <span style={{width: '36px', height: '36px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '19px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #36A8DE 30.04%, #9BCDFF 99.45%)'}}>R</span>
                <span style={{width: '36px', height: '36px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '19px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #4880FF 30.04%, #9BCDFF 99.45%)'}}>H</span>
                <span style={{width: '36px', height: '36px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '19px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #2196F3 30.04%, #9BCDFF 99.45%)'}}>C</span>
                <span style={{width: '36px', height: '36px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '19px', color: '#FFFFFF', background: 'linear-gradient(135.64deg, #6FB7FF 30.04%, #9BCDFF 99.45%)'}}>J</span>
              </div>
              <div style={{display: 'flex', justifyContent: 'center', gap: '16px'}}>
                <span style={{fontSize: '12px', color: '#333333', width: '36px', textAlign: 'center'}}>React</span>
                <span style={{fontSize: '12px', color: '#333333', width: '36px', textAlign: 'center'}}>HTML</span>
                <span style={{fontSize: '12px', color: '#333333', width: '36px', textAlign: 'center'}}>CSS</span>
                <span style={{fontSize: '12px', color: '#333333', width: '36px', textAlign: 'center'}}>JAVA</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuickAction;