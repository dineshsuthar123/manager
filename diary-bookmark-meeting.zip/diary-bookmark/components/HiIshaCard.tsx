import React from 'react'

type Props = {
    title?: string
    ctaText?: string
    birdSrc?: string
}

export default function HiIshaCard({
    title = "Hi Isha, Good Morning! Lets make your work day easy.",
    ctaText = 'Ask me anything',
    birdSrc,
}: Props) {
    return (
        <div className="hi-isha">
            {birdSrc ? (
                <img className="hi-bird" src={birdSrc} alt="assistant" />
            ) : (
                <svg className="hi-bird" viewBox="0 0 100 80" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="40" cy="40" r="28" fill="#ffd54f" />
                    <circle cx="32" cy="36" r="5" fill="#1f2937" />
                    <circle cx="48" cy="36" r="5" fill="#1f2937" />
                    <path d="M40 42 l6 6 l-12 0 z" fill="#ef6c00" />
                </svg>
            )}
            <div className="hi-waves" aria-hidden />
            <div className="hi-title">{title}</div>
            <button className="hi-cta" type="button">{ctaText}</button>
        </div>
    )
}