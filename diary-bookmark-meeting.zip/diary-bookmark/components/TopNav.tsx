import { Space, Badge, Avatar, Typography, Tooltip, Button } from 'antd'
import {
    SearchOutlined,
    EditOutlined,
    BookOutlined,
    AppstoreOutlined,
    BellOutlined,
    CalendarOutlined,
    MenuOutlined,
    UserOutlined,
    KeyOutlined,
    CheckCircleFilled,
} from '@ant-design/icons'

export default function TopNav() {
    return (
        <div className="topnav full">
            <div className="topnav-left">
                <div className="brand">
                    <MenuOutlined style={{ color: '#202224' }} />
                    <span className="brand-name">Nest</span>
                </div>
                <div className="tabs-toggle">
                    <button className="tab-pill is-active">My Workspace</button>
                    <button className="tab-pill">Manager Hub</button>
                </div>
            </div>

            <Space size={16} className="topnav-right">
                <div className="search-pill">
                    <SearchOutlined />
                    <UserOutlined />
                </div>
                <Tooltip title="Weekly Compliance">
                    <Button className="icon-btn" type="text" icon={<CheckCircleFilled style={{ color: '#009951' }} />} />
                </Tooltip>
                <Tooltip title="Diary">
                    <Button className="icon-btn" type="text" icon={<CalendarOutlined />} />
                </Tooltip>
                <Tooltip title="Notes">
                    <Button className="icon-btn" type="text" icon={<EditOutlined />} />
                </Tooltip>
                <Tooltip title="Bookmarks">
                    <Button className="icon-btn" type="text" icon={<BookOutlined />} />
                </Tooltip>
                <Tooltip title="Password">
                    <Button className="icon-btn" type="text" icon={<KeyOutlined />} />
                </Tooltip>
                <Tooltip title="Apps">
                    <Button className="icon-btn" type="text" icon={<AppstoreOutlined />} />
                </Tooltip>
                <Tooltip title="Notifications">
                    <Badge count={4} color="#F93C65" offset={[-4, 8]}>
                        <Button className="icon-btn" type="text" icon={<BellOutlined />} />
                    </Badge>
                </Tooltip>

                <div className="user-block">
                    <Avatar size={36} src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=120&auto=format&fit=crop" />
                    <div className="user-meta">
                        <Typography.Text className="user-name">Jone Aly</Typography.Text>
                        <Typography.Text type="secondary" className="user-role">Admin</Typography.Text>
                    </div>
                </div>
            </Space>
        </div>
    )
}